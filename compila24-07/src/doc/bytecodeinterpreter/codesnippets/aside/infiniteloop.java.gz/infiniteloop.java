int top = test.addInstruction(new NOP());
// here code for the body of the infinite loop could be added.
test.addInstruction(new JMP(top));
